from telegram import Update
from telegram.ext import ContextTypes
import models
from utils import get_translator

async def refer_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u, _ = models.User.get_or_create(user.id)
    _ = get_translator(u.language)
    ref_link = f"https://t.me/YourBot?start={u.id}"
    await update.callback_query.message.reply_text(_("Your referral link: {link}").format(link=ref_link))
