from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
import models, services.payments
from utils import get_translator

async def buy_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u, _ = models.User.get_or_create(user.id)
    _ = get_translator(u.language)
    buttons = [[InlineKeyboardButton("1 TH/s", callback_data="BUY_CONFIRM_1")]]
    await update.callback_query.message.reply_text(_("Select amount of TH/s to buy:"), reply_markup=InlineKeyboardMarkup(buttons))

async def buy_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer("Purchase confirmed!")
