from telegram import Update
from telegram.ext import ContextTypes
import models
from utils import get_translator

async def withdraw_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u, _ = models.User.get_or_create(update.effective_user.id)
    _ = get_translator(u.language)
    await update.callback_query.message.reply_text(_("Withdrawal feature coming soon."))
