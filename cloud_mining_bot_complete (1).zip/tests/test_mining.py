import pytest
from services.mining import calculate_daily_rate

def test_daily_rate():
    expected = (1 + 0.20)**(1/30) - 1
    assert pytest.approx(calculate_daily_rate(0.20), rel=1e-6) == expected
