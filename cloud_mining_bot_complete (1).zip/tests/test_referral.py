from services.referral import allocate_referral_bonus

def test_referral_bonus():
    assert allocate_referral_bonus(100) == pytest.approx(1.0)
