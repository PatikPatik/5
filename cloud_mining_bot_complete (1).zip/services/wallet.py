def debit(user, amount):
    # TODO: implement debit
    pass

def credit(user, amount):
    # TODO: implement credit
    pass
