def handle_deposit(user_id, amount):
    # TODO: implement integration with CryptoBot
    pass
