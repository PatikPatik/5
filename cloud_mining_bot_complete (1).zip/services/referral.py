def allocate_referral_bonus(profit):
    return profit * 0.01
